package com.jsd.customimagemodellabeling;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.ml.common.FirebaseMLException;
import com.google.firebase.ml.common.modeldownload.FirebaseModelDownloadConditions;
import com.google.firebase.ml.common.modeldownload.FirebaseModelManager;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.automl.FirebaseAutoMLLocalModel;
import com.google.firebase.ml.vision.automl.FirebaseAutoMLRemoteModel;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.label.FirebaseVisionImageLabel;
import com.google.firebase.ml.vision.label.FirebaseVisionImageLabeler;
import com.google.firebase.ml.vision.label.FirebaseVisionOnDeviceAutoMLImageLabelerOptions;

import java.io.IOException;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView img;
    Button btn_detect;
    TextView txt;
    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = findViewById(R.id.img);
        btn_detect = findViewById(R.id.btn_detect);
        txt = findViewById(R.id.txt);
        pd = new ProgressDialog(this);

        btn_detect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(i, "select an image.."), 0);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable final Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 0) {
            img.setImageURI(data.getData());

            FirebaseVisionImage image;
            try {
                image = FirebaseVisionImage.fromFilePath(getApplicationContext(), data.getData());

                FirebaseAutoMLLocalModel localModel = new FirebaseAutoMLLocalModel.Builder()
                        .setAssetFilePath("manifest.json")
                        .build();

                FirebaseVisionImageLabeler labeler;
                try {
                    FirebaseVisionOnDeviceAutoMLImageLabelerOptions options =
                            new FirebaseVisionOnDeviceAutoMLImageLabelerOptions.Builder(localModel)
                                    .setConfidenceThreshold(0.0f)  // Evaluate your model in the Firebase console
                                    // to determine an appropriate value.
                                    .build();
                    labeler = FirebaseVision.getInstance().getOnDeviceAutoMLImageLabeler(options);

                    labeler.processImage(image)
                            .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionImageLabel>>() {
                                @Override
                                public void onSuccess(List<FirebaseVisionImageLabel> labels) {
                                    // Task completed successfully
                                    // ...
                                    for (FirebaseVisionImageLabel label : labels) {
                                        String text = label.getText();
                                        float confidence = label.getConfidence();

                                        txt.append(text + "   " + confidence);
                                    }
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Task failed with an exception
                                    // ...
                                }
                            });
                } catch (FirebaseMLException e) {
                    // ...
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}


//                final FirebaseAutoMLRemoteModel remoteModel =
//                        new FirebaseAutoMLRemoteModel.Builder("Detect_Meds_20191212113955").build();
//
//                FirebaseModelDownloadConditions conditions = new FirebaseModelDownloadConditions.Builder()
//                        .requireWifi()
//                        .build();
//                FirebaseModelManager.getInstance().download(remoteModel, conditions)
//                        .addOnCompleteListener(new OnCompleteListener<Void>() {
//                            @Override
//                            public void onComplete(@NonNull Task<Void> task) {
//                                // Success.
//
//
//                                FirebaseModelManager.getInstance().isModelDownloaded(remoteModel)
//                                        .addOnSuccessListener(new OnSuccessListener<Boolean>() {
//                                            @Override
//                                            public void onSuccess(Boolean isDownloaded) {
//                                                FirebaseVisionOnDeviceAutoMLImageLabelerOptions.Builder optionsBuilder;
//                                                optionsBuilder = new FirebaseVisionOnDeviceAutoMLImageLabelerOptions.Builder(remoteModel);
//                                                FirebaseVisionOnDeviceAutoMLImageLabelerOptions options = optionsBuilder
//                                                        .setConfidenceThreshold(0.0f)  // Evaluate your model in the Firebase console
//                                                        // to determine an appropriate threshold.
//                                                        .build();
//
//                                                FirebaseVisionImageLabeler labeler;
//                                                try {
//                                                    labeler = FirebaseVision.getInstance().getOnDeviceAutoMLImageLabeler(options);
//                                                    image = FirebaseVisionImage.fromFilePath(getApplicationContext(), data.getData());
//                                                } catch (FirebaseMLException e) {
//                                                    // Error.
//                                                }
//                                            }
//                                        });
//                            }
//                        });
